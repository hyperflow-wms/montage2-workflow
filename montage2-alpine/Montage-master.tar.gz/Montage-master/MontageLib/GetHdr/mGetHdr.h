#ifndef MGETHDR_H
#define MGETHDR_H

/**************************************/
/* Define mGetHdr function prototypes */
/**************************************/

void mGetHdr_printFitsError(int);

#endif
