#ifndef MPUTHDR_H
#define MPUTHDR_H

/**************************************/
/* Define mPutHdr function prototypes */
/**************************************/

int    mPutHdr_readFits      (char *filename);
void   mPutHdr_printFitsError(int);
void   mPutHdr_printError    (char *);

#endif
