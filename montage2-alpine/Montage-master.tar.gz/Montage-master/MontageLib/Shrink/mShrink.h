#ifndef MSHRINK_H
#define MSHRINK_H

/**************************************/
/* Define mShrink function prototypes */
/**************************************/

int  mShrink_readFits      (char *fluxfile);
void mShrink_printFitsError(int);
void mShrink_printError    (char *);

#endif
