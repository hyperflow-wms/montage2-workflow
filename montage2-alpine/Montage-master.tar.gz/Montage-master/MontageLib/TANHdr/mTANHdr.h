#ifndef MTANHDR_H
#define MTANHDR_H

int      mTANHdr_gaussj(double **, int, double **, int);
int     *mTANHdr_ivector(int);
void     mTANHdr_free_ivector(int *);

#endif
